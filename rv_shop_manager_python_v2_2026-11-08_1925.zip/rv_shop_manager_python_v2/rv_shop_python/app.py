# RV Shop Manager - ricostruzione Python del progetto Base44
# Avvio: streamlit run app.py
import streamlit as st
import sqlite3, json, uuid, os
from datetime import datetime, date
from pathlib import Path
import pandas as pd

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "rv_shop.db"
UPLOAD_DIR = APP_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

st.set_page_config(page_title="RV Shop Manager", page_icon="🔧", layout="wide")

# Tutte le entità del modello Base44 condiviso: i campi sono conservati in JSON
# per mantenere anche i campi opzionali e consentire estensioni future.
ENTITIES = {
 "WorkOrder": ["ro_number","vehicle_id","year","make","model","customer_name","customer_phone","customer_email","odometer","work_classification","warranty_status","status","reception_notes"],
 "Job": ["work_order_id","ro_number","vehicle_label","job_number","title","description","category","pay_type","department","specialty","assigned_to_id","assigned_to_name","active_technician_id","active_technician_name","status","reception_notes","standard_minutes","net_minutes","waiting_minutes","active_since","efficiency_percent","waiting_started_at","block_reason","started_at","completed_at","transfer_note","warranty_decision","warranty_hours","warranty_reason","parts_ready"],
 "User": ["full_name","email","department","specialty","language","active"],
 "Part": ["part_number","name","description","quantity","min_stock","location"],
 "PartsRequest": ["work_order_id","ro_number","job_id","job_title","part_id","part_number","part_name","custom_item","unit","quantity_requested","unit_delivered","quantity_delivered","conversion_factor","repair_minutes","notes","photo_uris","supplier","order_number","status","warranty_claim_id","authorization","documents","defect_photos","defect_description","requested_by_id","requested_by_name","delivered_at","delivered_by","inventory_applied"],
 "WarrantyClaim": ["work_order_id","ro_number","vehicle_id","vehicle_label","job_id","job_title","component","problem_description","work_needed","requested_hours","approved_hours","status","decision_notes","photos","requested_by_id","requested_by_name","decided_by_name","decided_at"],
 "WarrantyReturn": ["work_order_id","ro_number","job_id","job_title","parts_request_id","part_name","part_number","quantity","received_date","defect_description","serial_number","reason","notes","photos","status","decision_notes","decided_by_name","decided_at","requested_by_id","requested_by_name"],
 "JobNote": ["job_id","work_order_id","author_id","author_name","department","text","translation","language"],
 "Attachment": ["work_order_id","job_id","file_uri","file_name","caption","uploaded_by_name","department"],
 "AuditLog": ["actor_id","actor_name","action","entity_type","entity_id","work_order_id","details"],
 "Notification": ["user_id","title","body","link","work_order_id","read"],
 "TimeEvent": ["job_id","work_order_id","mechanic_id","mechanic_name","type","event_at","note"],
 "JobAssignment": ["job_id","work_order_id","from_technician_id","from_technician_name","to_technician_id","to_technician_name","reason","note"],
}

ENUMS = {
 "WorkOrder.status":["open","in_progress","ready_inspection","ready_pickup","additional_work","completed","cancelled"],
 "WorkOrder.work_classification":["customer_pay","stock"],
 "WorkOrder.warranty_status":["not_applicable","pending","approved","partially_approved","declined"],
 "Job.status":["not_started","in_progress","paused","waiting_parts","waiting_warranty","completed","cancelled"],
 "Job.category":["customer_pay","warranty","stock"],
 "Job.pay_type":["customer_pay","warranty"],
 "Job.department":["technician","details"],
 "Job.specialty":["interior","engine","body","general","detailing"],
 "PartsRequest.status":["new","pending","preparing","ready_for_pickup","delivered","cancelled"],
 "WarrantyClaim.status":["submitted","in_review","approved","partially_approved","declined"],
 "WarrantyReturn.status":["submitted","in_review","return_approved","replacement_approved","credit_approved","declined"],
 "User.department":["reception","technician","details","parts","warranty","admin"],
 "User.language":["en","es","fr","it","de"],
}

def connect():
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.execute("""CREATE TABLE IF NOT EXISTS records(
        id TEXT PRIMARY KEY, entity TEXT NOT NULL, payload TEXT NOT NULL,
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_entity ON records(entity)")
    con.commit()
    return con

db = connect()

def rows(entity, filters=None):
    cur = db.execute("SELECT id,payload,created_at,updated_at FROM records WHERE entity=? ORDER BY created_at DESC",(entity,))
    result=[]
    for rid,p,created,updated in cur.fetchall():
        d=json.loads(p); d.update({"id":rid,"created_at":created,"updated_at":updated})
        if all(str(d.get(k,""))==str(v) for k,v in (filters or {}).items()):
            result.append(d)
    return result

def get(entity, rid):
    cur=db.execute("SELECT payload FROM records WHERE entity=? AND id=?",(entity,rid)).fetchone()
    return json.loads(cur[0]) if cur else None

def save(entity, data, rid=None, actor="Sistema"):
    now=datetime.now().isoformat(timespec="seconds")
    rid=rid or str(uuid.uuid4())
    clean={k:v for k,v in data.items() if k not in ("id","created_at","updated_at")}
    old=db.execute("SELECT created_at FROM records WHERE id=?",(rid,)).fetchone()
    created=old[0] if old else now
    db.execute("""INSERT INTO records(id,entity,payload,created_at,updated_at)
       VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET entity=excluded.entity,
       payload=excluded.payload,updated_at=excluded.updated_at""",
       (rid,entity,json.dumps(clean,ensure_ascii=False,default=str),created,now))
    db.commit()
    audit(actor,"create" if not old else "update",entity,rid,clean.get("work_order_id"),clean.get("title") or clean.get("name") or clean.get("ro_number") or "")
    return rid

def delete(entity,rid,actor="Sistema"):
    db.execute("DELETE FROM records WHERE entity=? AND id=?",(entity,rid)); db.commit()
    audit(actor,"delete",entity,rid,None,"Record eliminato")

def audit(actor,action,entity,rid,woid,details):
    now=datetime.now().isoformat(timespec="seconds")
    db.execute("INSERT INTO records VALUES(?,?,?,?,?)",
      (str(uuid.uuid4()),"AuditLog",json.dumps({"actor_name":actor,"action":action,"entity_type":entity,"entity_id":rid,"work_order_id":woid,"details":str(details)},ensure_ascii=False),now,now))
    db.commit()

def notify(user_id,title,body,work_order_id=None,link=""):
    save("Notification",{"user_id":user_id,"title":title,"body":body,"work_order_id":work_order_id,"link":link,"read":False})

def fmt_minutes(n):
    n=int(n or 0); return f"{n//60}h {n%60:02d}m"

def label_wo(w):
    return f"RO {w.get('ro_number','')} · {w.get('year','')} {w.get('make','')} {w.get('model','')} · {w.get('customer_name','')}"

def select_record(label, options, key, format_func=lambda x:x):
    if not options:
        st.info("Nessun elemento disponibile.")
        return None
    return st.selectbox(label,options,key=key,format_func=format_func)

def field_widget(entity, field, value=None, key=None):
    k=key or f"{entity}_{field}"
    enum=ENUMS.get(f"{entity}.{field}")
    if enum:
        opts=enum
        current=value if value in opts else opts[0]
        return st.selectbox(field.replace("_"," ").title(),opts,index=opts.index(current),key=k)
    if field in ("checklist","photo_uris","documents","defect_photos","photos"):
        val=value if value is not None else []
        return st.text_area(field.replace("_"," ").title()+" (JSON)",value=json.dumps(val,ensure_ascii=False,indent=2) if not isinstance(val,str) else val,key=k,help="Inserisci un array/oggetto JSON valido.")
    if field in ("year", "reception_notes","description","notes","problem_description","work_needed","decision_notes","defect_description","text","translation","caption","reason","transfer_note","block_reason"):
        return st.text_area(field.replace("_"," ").title(),value=str(value or ""),key=k)
    if field in ("quantity","min_stock","quantity_requested","quantity_delivered","conversion_factor","repair_minutes","standard_minutes","net_minutes","waiting_minutes","efficiency_percent","requested_hours","approved_hours","warranty_hours","odometer","job_number"):
        return st.number_input(field.replace("_"," ").title(),value=float(value or 0),step=1.0,key=k)
    if field in ("active","read","parts_ready","inventory_applied"):
        return st.checkbox(field.replace("_"," ").title(),value=bool(value),key=k)
    return st.text_input(field.replace("_"," ").title(),value=str(value or ""),key=k)

def entity_form(entity, initial=None, actor="Sistema", title=None, include_id=False):
    initial=initial or {}
    st.subheader(title or ("Modifica" if initial else "Nuovo") + " · " + entity)
    with st.form(f"form_{entity}_{initial.get('id','new')}_{st.session_state.get('form_counter',0)}"):
        data={}
        fields=ENTITIES[entity]
        cols=st.columns(2)
        for i,f in enumerate(fields):
            with cols[i%2]:
                data[f]=field_widget(entity,f,initial.get(f),key=f"f_{entity}_{initial.get('id','new')}_{f}_{st.session_state.get('form_counter',0)}")
        submitted=st.form_submit_button("Salva",type="primary",use_container_width=True)
    if submitted:
        for f in ("checklist","damages","photo_uris","documents","defect_photos","photos"):
            if isinstance(data.get(f),str):
                try: data[f]=json.loads(data[f] or "[]")
                except Exception: st.error(f"JSON non valido nel campo {f}"); return
        save(entity,data,initial.get("id"),actor)
        st.session_state.form_counter=st.session_state.get("form_counter",0)+1
        st.success("Salvato.")
        st.rerun()

def show_table(entity, data=None):
    data=data if data is not None else rows(entity)
    if not data:
        st.info("Nessun dato registrato.")
        return
    df=pd.DataFrame(data)
    visible=[c for c in df.columns if c not in ("created_at","updated_at","closed_at","closed_by","ready_at","unit_options","unit_cost","low_stock_notified_at") and not (entity=="Part" and c=="unit")]
    st.dataframe(df[visible],use_container_width=True,hide_index=True)

LANGUAGES = {"it":"Italiano", "en":"English", "fr":"Français", "de":"Deutsch", "es":"Español"}

def translate_note(text, source_lang, target_lang):
    """Traduzione online tramite GoogleTranslator (deep-translator)."""
    if not text or source_lang == target_lang:
        return text
    try:
        from deep_translator import GoogleTranslator
        return GoogleTranslator(source=source_lang or "auto", target=target_lang).translate(text) or text
    except Exception:
        return None

def translated_note(note, language):
    original = note.get("text", "")
    source = note.get("language", "it") or "it"
    translations = note.get("translation", {})
    if isinstance(translations, str):
        try: translations = json.loads(translations)
        except Exception: translations = {}
    if language == source:
        return original, False
    cached = translations.get(language) if isinstance(translations, dict) else None
    if cached:
        return cached, False
    translated = translate_note(original, source, language)
    if translated:
        translations = translations if isinstance(translations, dict) else {}
        translations[language] = translated
        note["translation"] = translations
        save("JobNote", note, note.get("id"), actor="Traduzione automatica")
        return translated, False
    return original, True

def normalize_items(value):
    if isinstance(value, str):
        try: value = json.loads(value or "[]")
        except Exception: value = []
    if not isinstance(value, list): value = []
    result=[]
    for item in value:
        if isinstance(item, str): result.append({"item":item,"note":"","done":False})
        elif isinstance(item, dict): result.append({"item":str(item.get("item", item.get("name", ""))),"note":str(item.get("note", "")),"done":bool(item.get("done", False))})
    return result

def work_order_lists(wo, actor):
    st.markdown("#### Lista attività")
    items=normalize_items(wo.get("checklist", []))
    for i, item in enumerate(items):
        a,b,c=st.columns([0.5,3,5])
        done=a.checkbox("",value=item["done"],key=f"wo_check_{wo['id']}_{i}")
        b.write(("☑ " if done else "□ ")+item["item"])
        c.caption(item["note"] or "Nessuna nota")
        if done != item["done"]:
            items[i]["done"]=done
            save("WorkOrder",{**wo,"checklist":items},wo["id"],actor)
            st.rerun()
    with st.form(f"add_check_{wo['id']}"):
        name=st.text_input("Nuova attività (es. Winterize, LED)")
        note=st.text_input("Nota attività")
        if st.form_submit_button("Aggiungi alla lista") and name.strip():
            items.append({"item":name.strip(),"note":note.strip(),"done":False})
            save("WorkOrder",{**wo,"checklist":items},wo["id"],actor); st.rerun()
    st.divider()
    st.markdown("#### Lista danni (Damages)")
    damages=normalize_items(wo.get("damages", []))
    for i,item in enumerate(damages):
        st.write(f"**{i+1}. {item['item']}** — {item['note'] or 'Nessuna nota'}")
    with st.form(f"add_damage_{wo['id']}"):
        damage=st.text_input("Danno")
        damage_note=st.text_input("Nota sul danno")
        if st.form_submit_button("Aggiungi danno") and damage.strip():
            damages.append({"item":damage.strip(),"note":damage_note.strip(),"done":False})
            save("WorkOrder",{**wo,"damages":damages},wo["id"],actor); st.rerun()

def choose_actor():
    users=rows("User")
    names=["Operatore locale"]+[u.get("full_name","Utente") for u in users]
    picked=st.sidebar.selectbox("Operatore",names,key="actor_pick")
    if picked=="Operatore locale": return "Operatore locale",None
    u=next((x for x in users if x.get("full_name")==picked),None)
    return picked,u

actor, actor_obj=choose_actor()
current_language = (actor_obj or {}).get("language") or st.session_state.get("local_language", "it")
lang_choice = st.sidebar.selectbox("Lingua personale", list(LANGUAGES.keys()), index=list(LANGUAGES.keys()).index(current_language) if current_language in LANGUAGES else 0, format_func=lambda x: LANGUAGES[x], key=f"personal_language_{actor_obj.get('id') if actor_obj else 'local'}")
if actor_obj and lang_choice != actor_obj.get("language"):
    actor_obj["language"] = lang_choice
    save("User", actor_obj, actor_obj["id"], actor)
elif not actor_obj:
    st.session_state.local_language = lang_choice
viewer_language = lang_choice
st.sidebar.caption("RV Shop Manager · Python")
page=st.sidebar.radio("Navigazione",[
 "Dashboard","Ordini di lavoro","Lavori / Tecnici","Magazzino ricambi",
 "Richieste ricambi","Garanzie","Resi in garanzia","Utenti","Report",
 "Allegati e note","Notifiche","Registro attività","Gestione dati"
])

st.title("🔧 RV Shop Manager")
st.caption("Gestione officina camper · dati salvati localmente in SQLite")

# Dashboard
if page=="Dashboard":
    wos=rows("WorkOrder"); jobs=rows("Job"); parts=rows("Part")
    c=st.columns(4)
    c[0].metric("Ordini aperti",sum(x.get("status") in ("open","in_progress","additional_work") for x in wos))
    c[1].metric("Lavori in corso",sum(x.get("status")=="in_progress" for x in jobs))
    c[2].metric("Richieste ricambi",sum(x.get("status") not in ("delivered","cancelled") for x in rows("PartsRequest")))
    c[3].metric("Ricambi sotto scorta",sum(float(x.get("quantity") or 0)<=float(x.get("min_stock") or 0) for x in parts))
    st.subheader("Ordini di lavoro recenti")
    show_table("WorkOrder",wos[:12])
    st.subheader("Lavori attivi")
    show_table("Job",[j for j in jobs if j.get("status") in ("in_progress","paused","waiting_parts","waiting_warranty")][:12])
    st.info("Suggerimento: crea prima un ordine di lavoro, poi aggiungi i lavori e assegna i tecnici.")

# Work orders
elif page=="Ordini di lavoro":
    tab1,tab2,tab3=st.tabs(["Elenco","Nuovo ordine","Modifica / chiusura"])
    with tab1:
        wos=rows("WorkOrder")
        status=st.selectbox("Filtra stato",["Tutti"]+ENUMS["WorkOrder.status"])
        show_table("WorkOrder",[w for w in wos if status=="Tutti" or w.get("status")==status])
    with tab2:
        entity_form("WorkOrder",actor=actor,title="Crea ordine di lavoro")
    with tab3:
        wos=rows("WorkOrder")
        selected=select_record("Seleziona ordine",wos,"edit_wo",label_wo)
        if selected:
            entity_form("WorkOrder",selected,actor,"Modifica ordine di lavoro")
            work_order_lists(selected, actor)

# Jobs
elif page=="Lavori / Tecnici":
    t1,t2,t3,t4=st.tabs(["Lavori","Aggiungi lavoro","Timer / stato","Note e assegnazioni"])
    jobs=rows("Job"); wos=rows("WorkOrder"); users=rows("User")
    with t1: show_table("Job",jobs)
    with t2:
        wo=select_record("Ordine di lavoro",wos,"job_wo",label_wo)
        if wo:
            with st.form("new_job"):
                title=st.text_input("Titolo intervento")
                description=st.text_area("Descrizione")
                category=st.selectbox("Categoria",ENUMS["Job.category"])
                dept=st.selectbox("Reparto",ENUMS["Job.department"])
                specialty=st.selectbox("Specialità",ENUMS["Job.specialty"])
                techs=[u for u in users if u.get("department") in ("technician","details")]
                tech=st.selectbox("Tecnico assegnato",["Non assegnato"]+techs,format_func=lambda x:x if isinstance(x,str) else x.get("full_name",""))
                standard=st.number_input("Tempo standard (minuti)",min_value=0,step=5)
                if st.form_submit_button("Crea lavoro",type="primary"):
                    save("Job",{"work_order_id":wo["id"],"ro_number":wo.get("ro_number"),"vehicle_label":label_wo(wo),"job_number":len([j for j in jobs if j.get("work_order_id")==wo["id"]])+1,"title":title,"description":description,"category":category,"pay_type":"warranty" if category=="warranty" else "customer_pay","department":dept,"specialty":specialty,"assigned_to_id":None if isinstance(tech,str) else tech["id"],"assigned_to_name":None if isinstance(tech,str) else tech.get("full_name"),"status":"not_started","standard_minutes":standard,"net_minutes":0,"waiting_minutes":0},actor=actor)
                    st.rerun()
    with t3:
        j=select_record("Seleziona lavoro",jobs,"timer_job",lambda x:f"RO {x.get('ro_number')} · {x.get('title')} · {x.get('status')}")
        if j:
            st.write(f"Stato: **{j.get('status')}** · Minuti lavorati: **{j.get('net_minutes',0)}** · Attesa: **{j.get('waiting_minutes',0)}**")
            a,b,c=st.columns(3)
            if a.button("▶ Avvia",disabled=j.get("status")=="in_progress"):
                now=datetime.now().isoformat()
                patch={**j,"status":"in_progress","active_since":now,"started_at":j.get("started_at") or now,"active_technician_name":actor}
                save("Job",patch,j["id"],actor); save("TimeEvent",{"job_id":j["id"],"work_order_id":j.get("work_order_id"),"mechanic_name":actor,"type":"start","event_at":now},actor=actor); st.rerun()
            if b.button("Ⅱ Pausa",disabled=j.get("status")!="in_progress"):
                mins=max(0,int((datetime.now()-datetime.fromisoformat(j["active_since"])).total_seconds()/60)) if j.get("active_since") else 0
                now=datetime.now().isoformat()
                save("Job",{**j,"status":"paused","net_minutes":int(j.get("net_minutes") or 0)+mins,"active_since":None},j["id"],actor)
                save("TimeEvent",{"job_id":j["id"],"work_order_id":j.get("work_order_id"),"mechanic_name":actor,"type":"pause","event_at":now},actor=actor); st.rerun()
            if c.button("✓ Completa",disabled=j.get("status")=="completed"):
                mins=max(0,int((datetime.now()-datetime.fromisoformat(j["active_since"])).total_seconds()/60)) if j.get("active_since") else 0
                now=datetime.now().isoformat()
                save("Job",{**j,"status":"completed","net_minutes":int(j.get("net_minutes") or 0)+mins,"active_since":None,"completed_at":now},j["id"],actor)
                save("TimeEvent",{"job_id":j["id"],"work_order_id":j.get("work_order_id"),"mechanic_name":actor,"type":"finish","event_at":now},actor=actor); st.rerun()
            reason=st.text_input("Motivo attesa (ricambi / garanzia)")
            if st.button("Metti in attesa") and reason:
                save("Job",{**j,"status":"waiting_parts" if "ricamb" in reason.lower() else "waiting_warranty","block_reason":reason,"waiting_started_at":datetime.now().isoformat(),"active_since":None},j["id"],actor); st.rerun()
    with t4:
        j=select_record("Lavoro",jobs,"note_job",lambda x:f"{x.get('ro_number')} · {x.get('title')}")
        if j:
            with st.form("job_note"):
                note=st.text_area("Nota")
                if st.form_submit_button("Aggiungi nota") and note.strip():
                    translations={}
                    for target_lang in LANGUAGES:
                        if target_lang != viewer_language:
                            translated=translate_note(note, viewer_language, target_lang)
                            if translated: translations[target_lang]=translated
                    save("JobNote",{"job_id":j["id"],"work_order_id":j.get("work_order_id"),"author_name":actor,"department":actor_obj.get("department") if actor_obj else "admin","text":note,"language":viewer_language,"translation":translations},actor=actor); st.rerun()
            with st.form("assign_job"):
                techs=[u for u in users if u.get("department") in ("technician","details")]
                assignee=st.selectbox("Assegna a",techs,format_func=lambda x:x.get("full_name",""))
                note_assign=st.text_input("Nota assegnazione")
                if st.form_submit_button("Assegna") and techs:
                    save("JobAssignment",{"job_id":j["id"],"work_order_id":j.get("work_order_id"),"to_technician_id":assignee["id"],"to_technician_name":assignee.get("full_name"),"reason":"transferred","note":note_assign},actor=actor)
                    save("Job",{**j,"assigned_to_id":assignee["id"],"assigned_to_name":assignee.get("full_name")},j["id"],actor); st.rerun()
            st.markdown("#### Note del lavoro")
            for note_record in rows("JobNote",{"job_id":j["id"]}):
                translated, failed = translated_note(note_record, viewer_language)
                st.markdown(f"**{note_record.get('author_name','')}** · {LANGUAGES.get(note_record.get('language','it'), note_record.get('language',''))}")
                st.write(translated)
                if failed: st.caption("Traduzione non disponibile: visualizzato il testo originale. Verificare la connessione internet.")
                if note_record.get("text") != translated:
                    with st.expander("Mostra testo originale"):
                        st.write(note_record.get("text", ""))

# Parts inventory
elif page=="Magazzino ricambi":
    t1,t2=st.tabs(["Inventario","Nuovo / modifica ricambio"])
    with t1:
        ps=rows("Part")
        low=[p for p in ps if float(p.get("quantity") or 0)<=float(p.get("min_stock") or 0)]
        if low:
            st.warning(f"{len(low)} ricambi sotto la scorta minima.")
            existing_notifications=rows("Notification")
            for lp in low:
                stock_link=f"low_stock:{lp['id']}"
                active_alert=next((n for n in existing_notifications if n.get("link")==stock_link and not n.get("read")),None)
                body=f"{lp.get('part_number','')} · {lp.get('name','')}: disponibili {lp.get('quantity',0)}, quantità minima {lp.get('min_stock',0)}"
                if not active_alert:
                    save("Notification",{"title":"Scorta ricambi bassa","body":body,"link":stock_link,"read":False},actor=actor)
                    existing_notifications=rows("Notification")
                st.error("Notifica scorta bassa — "+body)
        show_table("Part",ps)
        p=select_record("Ricambio da modificare",ps,"edit_part",lambda x:f"{x.get('part_number')} · {x.get('name')}")
        if p: entity_form("Part",p,actor,"Modifica ricambio")
    with t2: entity_form("Part",actor=actor,title="Nuovo ricambio")

# Parts requests
elif page=="Richieste ricambi":
    t1,t2,t3=st.tabs(["Richieste","Nuova richiesta","Consegna / aggiornamento"])
    reqs=rows("PartsRequest"); wos=rows("WorkOrder"); jobs=rows("Job"); parts=rows("Part")
    with t1: show_table("PartsRequest",reqs)
    with t2:
        wo=select_record("Ordine",wos,"req_wo",label_wo)
        if wo:
            related=[j for j in jobs if j.get("work_order_id")==wo["id"]]
            job=select_record("Lavoro (facoltativo)",related,"req_job",lambda x:x.get("title","")) if related else None
            with st.form("parts_req"):
                part=st.selectbox("Ricambio a catalogo (o lascia vuoto)",[None]+parts,format_func=lambda x:"Ricambio personalizzato" if x is None else f"{x.get('part_number')} · {x.get('name')}")
                custom=st.text_input("Descrizione ricambio personalizzato")
                qty=st.number_input("Quantità richiesta",min_value=0.01,value=1.0)
                unit=st.text_input("Unità",value="each")
                notes=st.text_area("Note")
                if st.form_submit_button("Invia richiesta",type="primary"):
                    name=part.get("name") if part else custom
                    if name:
                        save("PartsRequest",{"work_order_id":wo["id"],"ro_number":wo.get("ro_number"),"job_id":job.get("id") if job else None,"job_title":job.get("title") if job else None,"part_id":part.get("id") if part else None,"part_number":part.get("part_number") if part else None,"part_name":name,"custom_item":not bool(part),"unit":unit,"quantity_requested":qty,"status":"new","notes":notes,"requested_by_name":actor,"inventory_applied":False},actor=actor); st.rerun()
    with t3:
        r=select_record("Richiesta da aggiornare",reqs,"deliver_req",lambda x:f"RO {x.get('ro_number')} · {x.get('part_name')} · {x.get('status')}")
        if r:
            status=st.selectbox("Stato",ENUMS["PartsRequest.status"],index=ENUMS["PartsRequest.status"].index(r.get("status","new")) if r.get("status") in ENUMS["PartsRequest.status"] else 0)
            delivered=st.number_input("Quantità consegnata",min_value=0.0,value=float(r.get("quantity_delivered") or r.get("quantity_requested") or 0))
            if st.button("Salva stato richiesta"):
                patch={**r,"status":status,"quantity_delivered":delivered}
                if status=="delivered" and not r.get("inventory_applied") and r.get("part_id"):
                    part=get("Part",r["part_id"])
                    if part:
                        part["quantity"]=float(part.get("quantity") or 0)-delivered
                        save("Part",part,r["part_id"],actor); patch["inventory_applied"]=True
                if status=="delivered": patch["delivered_at"]=datetime.now().isoformat(); patch["delivered_by"]=actor
                save("PartsRequest",patch,r["id"],actor); st.rerun()

# Warranty
elif page=="Garanzie":
    t1,t2=st.tabs(["Pratiche","Nuova pratica"])
    claims=rows("WarrantyClaim"); wos=rows("WorkOrder"); jobs=rows("Job")
    with t1:
        show_table("WarrantyClaim",claims)
        claim=select_record("Pratica da decidere",claims,"claim_decide",lambda x:f"RO {x.get('ro_number')} · {x.get('problem_description','')[:50]} · {x.get('status')}")
        if claim:
            status=st.selectbox("Decisione",ENUMS["WarrantyClaim.status"],index=ENUMS["WarrantyClaim.status"].index(claim.get("status","submitted")))
            approved=st.number_input("Ore approvate",min_value=0.0,value=float(claim.get("approved_hours") or 0))
            notes=st.text_area("Note decisione")
            if st.button("Registra decisione"):
                save("WarrantyClaim",{**claim,"status":status,"approved_hours":approved,"decision_notes":notes,"decided_by_name":actor,"decided_at":datetime.now().isoformat()},claim["id"],actor)
                if claim.get("requested_by_id"): notify(claim["requested_by_id"],"Aggiornamento garanzia",status,claim.get("work_order_id"))
                st.rerun()
    with t2:
        wo=select_record("Ordine",wos,"claim_wo",label_wo)
        if wo:
            related=[j for j in jobs if j.get("work_order_id")==wo["id"]]
            job=select_record("Lavoro (facoltativo)",related,"claim_job",lambda x:x.get("title","")) if related else None
            with st.form("new_claim"):
                component=st.text_input("Componente")
                problem=st.text_area("Descrizione problema")
                work=st.text_area("Lavoro necessario")
                hours=st.number_input("Ore richieste",min_value=0.0)
                if st.form_submit_button("Invia pratica"):
                    if problem.strip():
                        save("WarrantyClaim",{"work_order_id":wo["id"],"ro_number":wo.get("ro_number"),"vehicle_label":label_wo(wo),"job_id":job.get("id") if job else None,"job_title":job.get("title") if job else None,"component":component,"problem_description":problem,"work_needed":work,"requested_hours":hours,"status":"submitted","requested_by_name":actor},actor=actor); st.rerun()

elif page=="Resi in garanzia":
    t1,t2=st.tabs(["Resi","Nuovo reso"])
    returns=rows("WarrantyReturn"); wos=rows("WorkOrder")
    with t1:
        show_table("WarrantyReturn",returns)
        r=select_record("Reso da decidere",returns,"return_decide",lambda x:f"RO {x.get('ro_number')} · {x.get('part_name')} · {x.get('status')}")
        if r:
            status=st.selectbox("Decisione reso",["return_approved","replacement_approved","credit_approved","declined"])
            notes=st.text_area("Note")
            if st.button("Salva decisione reso"):
                save("WarrantyReturn",{**r,"status":status,"decision_notes":notes,"decided_by_name":actor,"decided_at":datetime.now().isoformat()},r["id"],actor); st.rerun()
    with t2:
        wo=select_record("Ordine",wos,"return_wo",label_wo)
        if wo:
            with st.form("new_return"):
                name=st.text_input("Ricambio")
                number=st.text_input("Codice ricambio")
                qty=st.number_input("Quantità",min_value=1.0,value=1.0)
                defect=st.text_area("Descrizione difetto")
                reason=st.text_input("Motivo")
                if st.form_submit_button("Crea reso") and name.strip():
                    save("WarrantyReturn",{"work_order_id":wo["id"],"ro_number":wo.get("ro_number"),"part_name":name,"part_number":number,"quantity":qty,"defect_description":defect,"reason":reason,"status":"submitted","requested_by_name":actor},actor=actor); st.rerun()

elif page=="Utenti":
    t1,t2=st.tabs(["Elenco","Nuovo / modifica"])
    users=rows("User")
    with t1:
        show_table("User",users)
        u=select_record("Utente",users,"edit_user",lambda x:x.get("full_name",""))
        if u: entity_form("User",u,actor,"Modifica utente")
    with t2: entity_form("User",actor=actor,title="Nuovo utente")

elif page=="Report":
    wos=rows("WorkOrder"); jobs=rows("Job"); reqs=rows("PartsRequest")
    st.subheader("Riepilogo attività")
    st.write("Ordini per stato")
    if wos: st.bar_chart(pd.Series([x.get("status","sconosciuto") for x in wos]).value_counts())
    st.write("Lavori per stato")
    if jobs: st.bar_chart(pd.Series([x.get("status","sconosciuto") for x in jobs]).value_counts())
    st.write("Tempo registrato per tecnico")
    tech={}
    for j in jobs: tech[j.get("active_technician_name") or j.get("assigned_to_name") or "Non assegnato"]=tech.get(j.get("active_technician_name") or j.get("assigned_to_name") or "Non assegnato",0)+int(j.get("net_minutes") or 0)
    if tech: st.bar_chart(pd.Series(tech).sort_values(ascending=False))
    st.metric("Minuti lavorati registrati",sum(int(j.get("net_minutes") or 0) for j in jobs))
    st.metric("Richieste ricambi aperte",sum(r.get("status") not in ("delivered","cancelled") for r in reqs))

elif page=="Allegati e note":
    t1,t2=st.tabs(["Carica allegato","Note / allegati registrati"])
    with t1:
        wos=rows("WorkOrder"); wo=select_record("Ordine",wos,"att_wo",label_wo)
        jobs=[j for j in rows("Job") if not wo or j.get("work_order_id")==wo["id"]]
        job=select_record("Lavoro (facoltativo)",jobs,"att_job",lambda x:x.get("title","")) if jobs else None
        uploaded=st.file_uploader("Seleziona file")
        caption=st.text_input("Descrizione")
        if uploaded and st.button("Salva allegato"):
            dest=UPLOAD_DIR/f"{uuid.uuid4().hex}_{Path(uploaded.name).name}"
            dest.write_bytes(uploaded.getvalue())
            save("Attachment",{"work_order_id":wo.get("id") if wo else None,"job_id":job.get("id") if job else None,"file_uri":str(dest.relative_to(APP_DIR)),"file_name":uploaded.name,"caption":caption,"uploaded_by_name":actor},actor=actor); st.success("Allegato salvato.")
    with t2:
        st.subheader("Note interventi"); show_table("JobNote")
        st.subheader("Allegati"); show_table("Attachment")

elif page=="Notifiche":
    ns=rows("Notification")
    show_table("Notification",ns)
    unread=[n for n in ns if not n.get("read")]
    if unread and st.button("Segna tutte come lette"):
        for n in unread: save("Notification",{**n,"read":True},n["id"],actor)
        st.rerun()

elif page=="Registro attività":
    logs=rows("AuditLog")
    show_table("AuditLog",logs[:300])

elif page=="Gestione dati":
    st.warning("Strumenti amministrativi: esporta una copia prima di cancellare dati.")
    entity=st.selectbox("Tabella",list(ENTITIES.keys()))
    data=rows(entity)
    show_table(entity,data)
    if data:
        chosen=select_record("Record da modificare o eliminare",data,"generic_record",lambda x:f"{x.get('id')} · {x.get('name') or x.get('title') or x.get('ro_number') or x.get('part_name') or ''}")
        if chosen:
            entity_form(entity,chosen,actor,"Modifica record")
            if st.button("Elimina record selezionato",type="secondary"):
                delete(entity,chosen["id"],actor); st.rerun()
    st.divider()
    if st.button("Esporta backup JSON"):
        backup={e:rows(e) for e in ENTITIES}
        st.download_button("Scarica backup",json.dumps(backup,ensure_ascii=False,indent=2).encode("utf-8"),file_name=f"rv_shop_backup_{date.today()}.json",mime="application/json")
    uploaded_backup=st.file_uploader("Ripristina backup JSON",type=["json"])
    if uploaded_backup and st.button("Importa backup"):
        try:
            backup=json.loads(uploaded_backup.getvalue())
            for ent,items in backup.items():
                if ent in ENTITIES:
                    for item in items:
                        rid=item.pop("id",None); item.pop("created_at",None); item.pop("updated_at",None)
                        save(ent,item,rid,actor)
            st.success("Backup importato."); st.rerun()
        except Exception as e: st.error(f"Backup non valido: {e}")

st.sidebar.divider()
st.sidebar.caption(f"Database: {DB_PATH.name}")
st.sidebar.caption("Per backup: Gestione dati → Esporta backup JSON")
