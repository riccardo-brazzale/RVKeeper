RV SHOP MANAGER - VERSIONE PYTHON

REQUISITI
- Python 3.10 o superiore
- Connessione Internet per la traduzione automatica delle note

INSTALLAZIONE WINDOWS
1. Estrai tutti i file ZIP in una cartella.
2. Apri il Prompt dei comandi dentro la cartella che contiene app.py.
3. Esegui: python -m pip install -r requirements.txt
4. Esegui: python -m streamlit run app.py

AGGIORNAMENTI IN QUESTA VERSIONE
- Lingua personale selezionabile per ogni utente: italiano, inglese, francese, tedesco e spagnolo.
- Le note dei lavori vengono salvate nella lingua di chi le scrive e tradotte nelle altre lingue.
- Le traduzioni vengono mostrate secondo la lingua impostata dall'utente; il testo originale resta consultabile.
- La traduzione usa il servizio online Google tramite deep-translator: serve Internet. Se il servizio non risponde, la nota resta salvata e viene mostrata in originale.
- Ordini di lavoro: lista attività con nota per elemento (es. Winterize, LED) e lista danni con nota per elemento.
- Rimossi dai moduli ordine i campi Closed at, Closed by e Ready at.
- Il campo Year è ora un campo testuale/nota.
- Magazzino: rimossi Unit, Unit options e Unit cost. Gli avvisi di scorta bassa indicano quantità disponibile e quantità minima e vengono registrati in Notifiche.

NOTA IMPORTANTE
Questa è una prima ricostruzione locale in Streamlit/SQLite, non ancora un sistema multiutente online. Gli utenti possono usare preferenze diverse se condividono la stessa installazione/database. Per lavorare da computer diversi serve pubblicare l'app e configurare un database condiviso, autenticazione e permessi. Le traduzioni automatiche richiedono Internet e possono essere soggette a limiti del servizio esterno.

I dati sono salvati nel file rv_shop.db nella cartella dell'app. Esegui regolarmente un backup da Gestione dati.
